import 'package:graphx/graphx/display/display_object_container.dart';

class Sprite extends DisplayObjectContainer {}
