import 'dart:ui';

import 'package:graphx/graphx/display/display_object_container.dart';
import 'package:graphx/graphx/input/keyboard_manager.dart';
import 'package:graphx/graphx/input/pointer_manager.dart';

import '../display/display_object.dart';
import '../events/mixins.dart';
import '../scene_painter.dart';

class Stage extends DisplayObjectContainer
    with ResizeSignalMixin, TickerSignalMixin {
  final ScenePainter scene;

  Size _size;

  Paint _backgroundPaint;

  int get color => _backgroundPaint?.color?.value;

  set color(int value) {
    if (value == null) {
      _backgroundPaint = null;
    } else {
      _backgroundPaint ??= Paint();
      _backgroundPaint.color = Color(value);
    }
  }

  double get stageWidth => _size?.width ?? 0;

  double get stageHeight => _size?.height ?? 0;

  Stage(this.scene) {
    $stage = this;
    parent = null;
  }

  @override
  void paint(Canvas canvas) {
    /// scene start painting.
    if (_backgroundPaint != null) {
      canvas.drawPaint(_backgroundPaint);
    }
    super.paint(canvas);
  }

  void $initFrame(Size value) {
    if (value != _size) {
      _size = value;
      $onResized?.dispatch();
    }
    $onEnterFrame?.dispatch();
  }

  KeyboardManager get keyboard {
    if (scene?.core?.keyboard == null)
      throw 'You need to enable keyboard capture, define useKeyboard=true in your SceneController';
    return scene?.core?.keyboard;
  }

  PointerManager get pointer {
    if (scene?.core?.keyboard == null)
      throw 'You need to enable pointer capture, define usePointer=true in your SceneController';
    return scene?.core?.pointer;
  }

  void $tick() {}

  @override
  void addChildAt(int index, DisplayObject child) {
    child?.parent?.removeChild(child);
    child.parent = this;
    children.insert(index, child);
    child.$stage = stage;
    if (child is DisplayObjectContainer) {
      child.children.forEach((e) {
        e.$stage = child.stage;
      });
    }
  }

  @override
  void dispose() {
    super.dispose();
  }
}
