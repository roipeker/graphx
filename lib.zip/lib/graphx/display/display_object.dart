import 'dart:ui';

import 'package:graphx/graphx/events/mixins.dart';

import 'display_object_container.dart';
import 'stage.dart';

class DisplayObject with DisplayListSignalsMixin {
  Stage get stage => _stage;
  set $stage(Stage value) {
    if (stage == value) return;
    _stage = value;
    if (_stage != null) {
      $onAddedToStage?.dispatch();
    } else {
      $onRemovedFromStage?.dispatch();
    }
  }

  Stage _stage;
  DisplayObjectContainer parent;

  void paint(Canvas canvas) {}
  void dispose() {}

  void removeFromParent() {
    parent?.removeChild(this);
  }
}
