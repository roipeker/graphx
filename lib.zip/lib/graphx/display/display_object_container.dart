import 'package:graphx/graphx/display/display_object.dart';

class DisplayObjectContainer extends DisplayObject {
  final children = <DisplayObject>[];

  void addChild(DisplayObject child) {
    /// update stage in all children.
    addChildAt(children.length, child);
  }

  void addChildAt(int index, DisplayObject child) {
    if (child.parent == this) {
      /// optimize?
    }
    child?.parent?.removeChild(child);
    child.parent = this;
    children.insert(index, child);
    if (child is DisplayObjectContainer) {
      child.$stage = stage;
      child.children.forEach((e) {
        e.$stage = child.stage;
      });
    }
  }

  DisplayObject getChildAt(int index) {
    return null;
  }

  void removeChildren() {
    children.forEach((e) {
      e.removeFromParent();
    });
  }

  bool removeChild(DisplayObject child) {
    child.parent = null;
    return children.remove(child);
  }
}
