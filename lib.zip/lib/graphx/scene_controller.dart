import 'package:flutter/scheduler.dart';
import 'package:flutter/widgets.dart';
import 'package:graphx/graphx/input/keyboard_manager.dart';
import 'package:graphx/graphx/input/pointer_manager.dart';
import 'package:graphx/graphx/scene_painter.dart';

import 'input_converter.dart';

class SceneConfig {
  bool useKeyboard;
  bool usePointer;
  bool useTicker;
  bool painterIsComplex;
  bool painterWillChange;

  SceneConfig({
    this.useKeyboard = false,
    this.usePointer = false,
    this.useTicker = false,
    this.painterIsComplex = false,
    this.painterWillChange = true,
  });

  void copyFrom(SceneConfig other) {
    useKeyboard = other.useKeyboard;
    usePointer = other.usePointer;
    useTicker = other.useTicker;
    painterIsComplex = other.painterIsComplex;
    painterWillChange = other.painterWillChange;
  }
}

class SceneController {
  static SceneController current;

//  SceneController(SceneConfig configuration)
//      : _config = configuration ?? SceneConfig.fromDefault();

  ScenePainter back;
  ScenePainter front;
  Ticker _ticker;

  KeyboardManager get keyboard => _keyboard;

  PointerManager get pointer => _pointer;
  KeyboardManager _keyboard;
  PointerManager _pointer;

//  bool get usePointer => false;
//  bool get useKeyboard => false;
  InputConverter $inputConverter;

  SceneConfig get config => _config;
  SceneConfig _config = SceneConfig();

  void $init() {
    _ticker = Ticker(_onTick);
    _ticker.start();
    setup();
    _initInput();
  }

  void setup() {
    back?.setup();
    front?.setup();
  }

  void _onTick(Duration elapsed) {
    front?.tick();
    back?.tick();
  }

  void dispose() {
    front?.dispose();
    back?.dispose();
    _ticker?.stop(canceled: true);
    _ticker?.dispose();
    _ticker = null;
  }

  CustomPainter buildBackPainter() => back?.buildPainter();

  CustomPainter buildFrontPainter() => front?.buildPainter();

  void _initInput() {
    if (_config.useKeyboard) {
//      _keyboardFocusNode = FocusNode();
      _keyboard ??= KeyboardManager();
    }
    if (_config.usePointer) {
      _pointer ??= PointerManager();
    }
    if (_config.useKeyboard || _config.usePointer) {
      $inputConverter ??= InputConverter(_pointer, _keyboard);
    }
  }

  SceneController._();

  static SceneController withLayers({RootScene back, RootScene front}) {
    assert(back != null || front != null);
    final controller = SceneController._();
    if (back != null) {
      controller.back = ScenePainter(controller, back);
    }
    if (front != null) {
      controller.front = ScenePainter(controller, front);
    }
    return controller;
  }
}
