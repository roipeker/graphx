import 'input_converter.dart';

class Graphx {
  static Graphx instance = Graphx();

  static init() {}
}
