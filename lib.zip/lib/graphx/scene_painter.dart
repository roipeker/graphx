import 'package:flutter/widgets.dart';
import 'package:graphx/graphx/display/display_object.dart';
import 'package:graphx/graphx/display/sprite.dart';
import 'package:graphx/graphx/scene_controller.dart';

import 'display/stage.dart';
import 'events/mixins.dart';

class RootScene extends Sprite {
  void init() {
    /// much like a constructor...
  }
  void ready() {
    /// when stage is ready!
  }
}

class ScenePainter with EventDispatcherMixin {
  /// base for painter.
  SceneController core;
  RootScene root;

  /// allows to repaint on every tick()
  bool needsRepaint = true;

  ScenePainter(this.core, this.root) {
    _stage = Stage(this);
  }

  CustomPainter buildPainter() => _GraphicsPainter(this);

  Canvas canvas;

  Size size = Size.zero;
  Stage _stage;

  Stage get stage => _stage;

  bool _isReady = false;
  bool get isReady => _isReady;

  /// stage is here.
  void _paint(Canvas canvas, Size size) {
    size = size;
    canvas = canvas;
    _stage.$initFrame(size);
    _stage.paint(canvas);
    if (!_isReady) {
      _isReady = true;
      _stage.addChild(root);
      root.ready();
    }
//    core.$paint();
  }

  void setup() {
    root.init();
  }

  bool shouldRepaint() => needsRepaint;

  void tick() {
    _stage.$tick();
    if (needsRepaint) {
      notify();
    }
  }

  @override
  void dispose() {
    _stage?.dispose();
    super.dispose();
  }
}

class _GraphicsPainter extends CustomPainter {
  final ScenePainter scene;

  _GraphicsPainter(this.scene) : super(repaint: scene);

  @override
  void paint(Canvas canvas, Size size) {
    scene._paint(canvas, size);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) =>
      scene.shouldRepaint();
}
