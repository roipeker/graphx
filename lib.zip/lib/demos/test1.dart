import 'package:graphx/graphx/scene_painter.dart';

class MainFrontScene extends RootScene {
  @override
  void ready() {
    print("front Stage is: $stage");
  }
}

class MainBackScene extends RootScene {
  @override
  void ready() {
    print("back Stage is: $stage");
  }
}
